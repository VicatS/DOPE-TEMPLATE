Author: CodexWorld
Author URL: http://www.codexworld.com
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/codeigniter-send-email-using-phpmailer-gmail-smtp/

Installation Instructions:
==================================================
1. Move all files to the same directory of your CodeIgniter application.
2. Open the Email controller in a editor ==> Specify the SMTP server details and configurate the email receipient and other settings.
3. Open the URL of the send method of Email controller (http://localhost/project_folder_name/email/send/) on the browser and test the Email functionality with PHPMailer.

============ May I Help You ===========
If you have any query about this script, send us by posting a comment here - http://www.codexworld.com/codeigniter-send-email-using-phpmailer-gmail-smtp/#respond.
