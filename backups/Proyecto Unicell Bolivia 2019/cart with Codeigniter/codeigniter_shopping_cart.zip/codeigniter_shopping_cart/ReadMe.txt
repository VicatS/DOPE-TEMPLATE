Author: CodexWorld
Author URL: http://www.codexworld.com
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/codeigniter-shopping-cart-checkout-implementation/

Installation Instructions:
==================================================
1. Import the "SQL/shopping_cart.sql" file into the database of your CodeIgniter application.
2. Move all files to the same directory of your CodeIgniter application.\
3. Open the Product controller URL (http://localhost/project_folder_name/products/) on the browser and test the Shopping Cart functionality.

============ May I Help You ===========
If you have any query about this script, send us by posting a comment here - http://www.codexworld.com/codeigniter-shopping-cart-checkout-implementation/#respond.
