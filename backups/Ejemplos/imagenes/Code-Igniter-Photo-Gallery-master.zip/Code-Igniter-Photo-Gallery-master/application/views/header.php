<html>

<head>

<script src="<?=base_url("js/jquery.js")?>"> </script>
<script src="<?=base_url("js/main.js")?>"> </script>
<script src="<?=base_url("js/bootstrap.js")?>"> </script>
<link rel="stylesheet" href="<?= base_url("css/bootstrap.css"); ?>" type="text/css" />

<link rel="stylesheet" href="<?= base_url("css/style.css"); ?>" type="text/css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" />

</head>
<body>

