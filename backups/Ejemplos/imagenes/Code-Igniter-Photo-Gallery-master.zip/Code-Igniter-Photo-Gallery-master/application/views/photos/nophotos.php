<div class="container">


<h1> No photos </h1>

<p> This album has no photos, please login as an administrator in order to put some photos </p>

</div>