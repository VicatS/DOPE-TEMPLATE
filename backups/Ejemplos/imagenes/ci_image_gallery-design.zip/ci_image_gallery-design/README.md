# Codeigniter 3 Project - Image Gallery Application

Whit this simple application you can show, add, update and delete images
