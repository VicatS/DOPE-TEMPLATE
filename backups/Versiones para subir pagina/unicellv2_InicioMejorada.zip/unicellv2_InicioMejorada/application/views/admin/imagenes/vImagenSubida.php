<div>	
	<h1><?php echo $titulo ?></h1>
	<img src="<?=base_url()?>imagenes/thumbs/<?php echo $imagen;?>">
</div>