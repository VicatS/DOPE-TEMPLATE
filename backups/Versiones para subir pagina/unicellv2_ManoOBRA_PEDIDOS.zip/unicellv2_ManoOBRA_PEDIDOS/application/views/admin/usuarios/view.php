<p><strong>Nombres:</strong> <?php echo $usuario->nombrecompleto; ?></p>
