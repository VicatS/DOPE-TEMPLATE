<p><strong>Nombre:</strong> <?php echo $marca->nombreMarca; ?></p>
<p><strong>Descripción:</strong> <?php echo $marca->descripcion; ?></p>