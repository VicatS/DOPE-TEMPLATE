<p><strong>Nombre:</strong> <?php echo $categoria->nombreCategoria; ?></p>
<p><strong>Descripción:</strong> <?php echo $categoria->descripcion; ?></p>