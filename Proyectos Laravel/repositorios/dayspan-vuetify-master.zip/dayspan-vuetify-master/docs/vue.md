# Vue Documentation

#### [Vue](https://vuejs.org/v2/guide/instance.html)
