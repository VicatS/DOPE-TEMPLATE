# WEB API Documentation

#### [HTMLElement](https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement)
