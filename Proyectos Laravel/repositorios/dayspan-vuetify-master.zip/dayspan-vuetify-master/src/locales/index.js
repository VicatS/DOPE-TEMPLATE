
import en from './en'
import nl from './nl'

export default {
  'en': en,
  'en-US': en
}

export const defaultLocale = 'en'
