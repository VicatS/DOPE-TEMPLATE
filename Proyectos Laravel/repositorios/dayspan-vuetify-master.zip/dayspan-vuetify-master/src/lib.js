
import './styles/lib.scss'

import DaySpanVuetify from './plugin'

export * from './components';

export default DaySpanVuetify;
